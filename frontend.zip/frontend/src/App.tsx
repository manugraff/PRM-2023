import TopicPage from "./pages/Topic"

function App() {
  return (
    <div id="App">
      <TopicPage />
    </div>
  )
}

export default App
