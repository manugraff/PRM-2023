import { Typography } from "@mui/material";

function TopicCardBody() {
    return (
        <div id="topic-card-body" style={{marginLeft: '3rem'}}>
            <Typography variant="body1">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic, dolorum? Delectus fuga dolore at eos, est mollitia, asperiores quibusdam ab, possimus quas soluta quos. Ut delectus debitis aliquid velit atque!
            </Typography>
        </div>
    )
}

export default TopicCardBody;